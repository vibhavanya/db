package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import exception.DatabaseConnectivityException;

public class ConnectionUtil {
	private static final String URL = "jdbc:mysql://localhost:3306/engineeringcamp";
	private static final String USERNAME = "root";
	private static final String PASSWORD = "root";

	public static Connection getConnection() throws DatabaseConnectivityException{
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
		} catch (SQLException e) {
			throw new DatabaseConnectivityException("Unable to connect to database",e);
		}
		return connection;
	}
}
