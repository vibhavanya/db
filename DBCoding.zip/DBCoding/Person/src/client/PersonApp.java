package client;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import entity.Person;
import exception.InvalidPhoneNoException;
import exception.ServiceException;
import service.impl.PersonServiceImpl;

public class PersonApp {
	static Scanner sc = new Scanner(System.in);
	static PersonServiceImpl ob = new PersonServiceImpl();

	public static void main(String[] args) throws ServiceException {
		boolean check = true;
		while (check) {
			showMenu();
			int option = sc.nextInt();
			switch (option) {
			case 1:
				Set<Person> person = new HashSet<>();
				for (int i = 0; i < 1; i++) {
					System.out.println("Insert person id:");
					int id = sc.nextInt();
					System.out.println("Insert person name:");
					String name = sc.next();
					System.out.println("Insert phoneno");
					
					try {
						String phoneno = sc.next();
						String phoneNo=ob.validatePhoneno(phoneno);
						Person p = new Person(id, name, phoneNo);
						person.add(p);
					} catch (InvalidPhoneNoException e) {
					System.out.println(e.getMessage());
				}
				}
				try {
					ob.getAllPerson(person);
				} catch (ServiceException e) {
					e.printStackTrace();
				}
				break;
			case 2:
				Set<Person> end = null;
				try {
					end = ob.getDetails();
				} catch (ServiceException e) {
					e.printStackTrace();
				}
				for (Person person2 : end) {
					System.out.println(person2);
				}
				break;
			case 3:
				System.exit(0);
				break;
			}
		}

	}

//	private static int noinvalid(long no) throws InvalidPhoneNoException {
//		int count = 0;
//		while (no != 0) {
//			no = no / 10;
//			count++;
//
//		}
//		if (count != 10)
//			throw new InvalidPhoneNoException("Phone no. is invalid");
//		
//		
//	}

	private static void showMenu() {
		System.out.println("1.Insert a person");
		System.out.println("2.Display");
		System.out.println("3.Exit");
	}
}