package service.impl;

import java.util.Set;

import dao.PersonDao;
import dao.impl.PersonDaoImpl;
import entity.Person;
import exception.DaoException;
import exception.InvalidPhoneNoException;
import exception.ServiceException;
import service.PersonService;

public class PersonServiceImpl implements PersonService {
	private PersonDao personDao = new PersonDaoImpl();
	PersonDao po = new PersonDaoImpl();

	@Override
	public Set<Person> getAllPerson(Set<Person> person) throws ServiceException {
		Set<Person> people;
		try {
			people = po.getAllPerson(person);
			
		} catch (DaoException e) {
			throw new ServiceException(e);
		}
		return people;
	}

	@Override
	public Set<Person> getDetails() throws ServiceException {
		Set<Person> pers;
		try {
			pers = personDao.getDetails();
		} catch (DaoException e) {
			throw new ServiceException(e);
		}
		return pers;
	}

	public String validatePhoneno(String phoneno) throws InvalidPhoneNoException {
		if (phoneno.length()==10)
			return phoneno;
		else {
			throw new InvalidPhoneNoException("Phone no. is invalid");
		}
	}

}
