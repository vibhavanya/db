package service;

import java.util.Set;

import entity.Person;
import exception.DaoException;
import exception.ServiceException;

public interface PersonService {

	/**
	 * @param person enter the details for person
	 * @throws DaoException 
	 * @throws ServiceException 
	 */
	Set<Person> getAllPerson(Set<Person> person) throws DaoException, ServiceException;

	/**
	 * @return the details of person
	 * @throws DaoException 
	 * @throws ServiceException 
	 */
	Set<Person> getDetails() throws DaoException, ServiceException;
}
