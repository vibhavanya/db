package dao;

import java.util.Set;

import entity.Person;
import exception.DaoException;

public interface PersonDao {
	/**
	 * @param person insert the values for persons
	 * @return
	 */
	Set<Person>  getAllPerson(Set<Person>person)throws DaoException;
	
	/**
	 * @return returns the details for person
	 */
	Set<Person> getDetails()throws DaoException;
}
