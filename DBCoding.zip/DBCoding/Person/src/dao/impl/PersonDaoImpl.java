package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import dao.PersonDao;
import entity.Person;
import exception.DaoException;
import exception.DatabaseConnectivityException;
import util.ConnectionUtil;

public class PersonDaoImpl implements PersonDao {
	ConnectionUtil cu = new ConnectionUtil();

	@Override
	public Set<Person> getAllPerson(Set<Person> person) throws DaoException {
		// create connection
		Connection con = null;
		try {
			con = ConnectionUtil.getConnection();
		} catch (DatabaseConnectivityException e1) {
			e1.printStackTrace();
		}
		// create statement
		Statement s = null;
		for (Person person2 : person) {

			String query = "Insert into person values(" + person2.getId() + ",'" + person2.getName() + "',"+ person2.getPhoneno() + ");";
			try {
				s = con.createStatement();
				s.executeUpdate(query);
				s.close();
			} catch (SQLException e) {
				throw new DaoException(e);
			}
		 finally {
			try {
				con.close();
			} catch (SQLException e) {
				throw new DaoException(e);
			}
		}}
		return person;
	}

	@Override
	public Set<Person> getDetails() throws DaoException{
		Set<Person> result = new HashSet<>();
		Connection con = null;
		try {
			con = ConnectionUtil.getConnection();
		} catch (DatabaseConnectivityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Statement s = null;
		try {
			s = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		String query = "Select * from person;";
		try {
			ResultSet rs = s.executeQuery(query);
			while (rs.next()) {
				Person p = new Person(rs.getInt(1), rs.getString(2),rs.getString(3));
				result.add(p);

			}
		} catch (SQLException e) {
			throw new DaoException(e);
		}
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}

}